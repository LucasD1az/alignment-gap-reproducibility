# v0.2.1 — Full-data reproducibility workflow

This patch removes the separate simulated demonstration workflow introduced in v0.2.0 and uses the bundled anonymized research dataset as the executable example.

## Removed

- `config/demo.yml`.
- `data/demo/` and all simulated records.
- `scripts/prepare_demo_data.py`.
- `scripts/run_demo.py`.
- `src/alignment_gap/demo.py`.
- Demo-specific tests and documentation.

## Changed

- The README quick start now validates and reproduces the complete research dataset.
- The complete workflow writes per-figure and total runtimes to `results/reproduction_runtime.json`.
- GitHub Actions validates the public data on Python 3.10–3.12 and runs the full reproduction on Python 3.11.
- The checklist mapping documents the deliberate decision not to include a reduced dataset because it can alter the paper's correlations, lags, geographic estimates, and figure appearance.
- Version metadata updated to 0.2.1.

## After applying

Run:

```bash
python -m pip install -e ".[dev]"
python scripts/validate_public_data.py
python scripts/reproduce_all.py
python scripts/report_environment.py --output results/environment.json
pytest
```

Before Code Ocean import, copy the measured installation and full-reproduction times into `docs/ENVIRONMENT_AND_RUNTIME.md` and the README.
