# Environment and runtime record

The complete reproduction writes a machine-readable report automatically:

```text
results/reproduction_runtime.json
```

Create a standalone environment report with:

```bash
python scripts/report_environment.py --output results/environment.json
```

For the final submission record, run these commands on the author workstation and copy the values below.

| Measurement | Value |
|---|---|
| Operating system | Fill from `results/environment.json` |
| Python version | Fill from `results/environment.json` |
| CPU and RAM | Fill from `results/environment.json` |
| Installation time | Measure using the command in `README.md` |
| Full reproduction time | Fill from `results/reproduction_runtime.json` |

The GitHub Actions workflow provides an additional reproducible test record on Ubuntu 24.04 with Python 3.10–3.12. The complete full-data reproduction is run in continuous integration on Python 3.11.
